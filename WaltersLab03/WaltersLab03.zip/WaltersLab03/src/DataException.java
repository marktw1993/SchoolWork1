
public class DataException extends Throwable
{
	public DataException()
	{
		super("Invalid data range");
	}
}
